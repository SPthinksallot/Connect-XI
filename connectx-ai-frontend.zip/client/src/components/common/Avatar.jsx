const SIZE_MAP = {
  sm: "h-8 w-8 text-xs",
  md: "h-10 w-10 text-sm",
  lg: "h-14 w-14 text-base",
};

const PALETTE = [
  "bg-violet-500",
  "bg-mint-500",
  "bg-amber-500",
  "bg-coral-500",
];

function colorForName(name = "") {
  const code = name.charCodeAt(0) || 0;
  return PALETTE[code % PALETTE.length];
}

export default function Avatar({ name, initials, size = "md", showStatus, status }) {
  const sizeClasses = SIZE_MAP[size] ?? SIZE_MAP.md;
  const bg = colorForName(name ?? initials);

  return (
    <div className="relative inline-flex shrink-0">
      <div
        className={`${sizeClasses} ${bg} flex items-center justify-center rounded-full font-display font-medium text-white`}
        aria-hidden="true"
      >
        {initials}
      </div>
      {showStatus && (
        <span
          className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full ring-2 ring-paper-50 dark:ring-ink-900 ${
            status === "online" ? "bg-mint-500" : "bg-ink-400"
          }`}
          aria-label={status === "online" ? "Online" : "Offline"}
        />
      )}
    </div>
  );
}
