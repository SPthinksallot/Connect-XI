import { MessageSquareText } from "lucide-react";

export default function EmptyState() {
  return (
    <div className="flex h-full flex-1 flex-col items-center justify-center gap-3 bg-paper-50 text-center dark:bg-ink-900">
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-violet-500/10">
        <MessageSquareText className="h-7 w-7 text-violet-500" />
      </div>
      <h2 className="font-display text-lg font-medium">Pick a conversation</h2>
      <p className="max-w-xs text-sm text-ink-400">
        Select a chat from the left, or start a new one to begin messaging.
      </p>
    </div>
  );
}
