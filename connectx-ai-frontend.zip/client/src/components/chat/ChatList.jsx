import { Search, SquarePen } from "lucide-react";
import ChatListItem from "./ChatListItem";
import Avatar from "../common/Avatar";
import ThemeToggle from "../theme/ThemeToggle";

export default function ChatList({ chats, contactsById, activeChatId, onSelectChat, currentUser }) {
  return (
    <aside className="flex h-full w-full max-w-[360px] flex-col border-r border-ink-200/10 bg-paper-50 dark:bg-ink-900">
      {/* Header */}
      <div className="flex items-center justify-between px-5 pt-5 pb-3">
        <div className="flex items-center gap-2">
          <div className="h-2.5 w-2.5 rounded-full bg-violet-500" />
          <h1 className="font-display text-lg font-semibold tracking-tight">
            ConnectX <span className="text-violet-500">AI</span>
          </h1>
        </div>
        <div className="flex items-center gap-1">
          <ThemeToggle />
          <button
            aria-label="Start new conversation"
            className="flex h-9 w-9 items-center justify-center rounded-full text-ink-500 transition-colors hover:bg-ink-100 dark:text-paper-200 dark:hover:bg-ink-800"
          >
            <SquarePen className="h-4.5 w-4.5" />
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="px-4 pb-3">
        <div className="flex items-center gap-2 rounded-xl bg-ink-100/70 px-3 py-2 dark:bg-ink-800/70">
          <Search className="h-4 w-4 text-ink-400" />
          <input
            type="text"
            placeholder="Search people, groups, or messages"
            className="w-full bg-transparent text-sm text-ink-900 placeholder:text-ink-400 outline-none dark:text-paper-50"
          />
        </div>
      </div>

      {/* Chat list */}
      <nav className="scrollbar-thin flex-1 space-y-0.5 overflow-y-auto px-2 pb-3">
        {chats.map((chat) => {
          const contact = contactsById[chat.contactId];
          if (!contact) return null;
          return (
            <ChatListItem
              key={chat.id}
              contact={contact}
              lastMessage={chat.lastMessage}
              unreadCount={chat.unreadCount}
              isActive={chat.id === activeChatId}
              onClick={() => onSelectChat(chat.id)}
            />
          );
        })}
      </nav>

      {/* Current user footer */}
      <div className="flex items-center gap-3 border-t border-ink-200/10 px-4 py-3">
        <Avatar
          name={currentUser.displayName}
          initials={currentUser.initials}
          size="sm"
          showStatus
          status="online"
        />
        <div className="flex-1 overflow-hidden">
          <p className="truncate text-sm font-medium">{currentUser.displayName}</p>
          <p className="truncate text-xs text-ink-400">Online</p>
        </div>
      </div>
    </aside>
  );
}
