import Avatar from "../common/Avatar";

function formatTime(iso) {
  const date = new Date(iso);
  const now = new Date();
  const isToday = date.toDateString() === now.toDateString();
  if (isToday) {
    return date.toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" });
  }
  return date.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}

export default function ChatListItem({ contact, lastMessage, unreadCount, isActive, onClick }) {
  const isMine = lastMessage?.sender === "u1";
  const preview =
    lastMessage?.contentType === "audio"
      ? "🎤 Voice note"
      : lastMessage?.text || "Start the conversation";

  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors duration-150 ${
        isActive
          ? "bg-violet-500/10"
          : "hover:bg-ink-100/60 dark:hover:bg-ink-800/60"
      }`}
    >
      <Avatar
        name={contact.displayName}
        initials={contact.initials}
        showStatus={!contact.isGroup}
        status={contact.status}
      />
      <div className="flex-1 overflow-hidden">
        <div className="flex items-center justify-between gap-2">
          <p className="truncate font-medium text-ink-900 dark:text-paper-50">
            {contact.displayName}
          </p>
          {lastMessage && (
            <span className="shrink-0 font-mono text-[11px] text-ink-400">
              {formatTime(lastMessage.createdAt)}
            </span>
          )}
        </div>
        <div className="flex items-center justify-between gap-2">
          <p className="truncate text-sm text-ink-500 dark:text-ink-300">
            {isMine && <span className="text-ink-400">You: </span>}
            {preview}
          </p>
          {unreadCount > 0 && (
            <span className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-violet-500 px-1.5 text-[11px] font-semibold text-white">
              {unreadCount}
            </span>
          )}
        </div>
      </div>
    </button>
  );
}
