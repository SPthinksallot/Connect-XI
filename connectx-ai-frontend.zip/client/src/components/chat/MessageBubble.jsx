import { useState } from "react";
import { Check, CheckCheck, Languages, Image as ImageIcon } from "lucide-react";

function formatTime(iso) {
  return new Date(iso).toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" });
}

function StatusTicks({ status }) {
  if (status === "read") return <CheckCheck className="h-3.5 w-3.5 text-violet-300" />;
  if (status === "delivered") return <CheckCheck className="h-3.5 w-3.5 text-white/50" />;
  return <Check className="h-3.5 w-3.5 text-white/50" />;
}

export default function MessageBubble({ message, isMine }) {
  const [showTranslation, setShowTranslation] = useState(false);
  const hasTranslation = Boolean(message.translatedText?.en);

  const displayText =
    showTranslation && hasTranslation ? message.translatedText.en : message.text;

  return (
    <div className={`flex ${isMine ? "justify-end" : "justify-start"}`}>
      <div className={`group relative max-w-[70%] ${isMine ? "items-end" : "items-start"}`}>
        <div
          className={`rounded-2xl px-4 py-2.5 ${
            isMine
              ? "rounded-br-md bg-violet-500 text-white"
              : "rounded-bl-md bg-ink-100 text-ink-900 dark:bg-ink-800 dark:text-paper-50"
          }`}
        >
          {message.contentType === "image" ? (
            <div className="flex h-40 w-56 items-center justify-center rounded-lg bg-ink-200/50 dark:bg-ink-700/50">
              <ImageIcon className="h-8 w-8 text-ink-400" />
            </div>
          ) : (
            <p className="text-sm leading-relaxed">{displayText}</p>
          )}
        </div>

        <div
          className={`mt-1 flex items-center gap-1.5 px-1 ${
            isMine ? "justify-end" : "justify-start"
          }`}
        >
          {hasTranslation && (
            <button
              onClick={() => setShowTranslation((s) => !s)}
              className={`flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[11px] font-medium transition-colors ${
                showTranslation
                  ? "text-violet-500"
                  : "text-ink-400 hover:text-violet-500"
              }`}
            >
              <Languages className="h-3 w-3" />
              {showTranslation ? "Original" : "Translate"}
            </button>
          )}
          <span className="font-mono text-[11px] text-ink-400">
            {formatTime(message.createdAt)}
          </span>
          {isMine && <StatusTicks status={message.status} />}
        </div>
      </div>
    </div>
  );
}
