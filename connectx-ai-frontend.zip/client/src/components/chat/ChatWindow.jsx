import { useEffect, useRef, useState } from "react";
import ChatWindowHeader from "./ChatWindowHeader";
import MessageBubble from "./MessageBubble";
import MessageInput from "./MessageInput";
import TypingIndicator from "./TypingIndicator";
import SmartReplySuggestions from "../ai/SmartReplySuggestions";
import ChatSummaryModal from "../ai/ChatSummaryModal";
import { smartReplySuggestions, chatSummaryExample } from "../../data/mockData";

function DateDivider({ label }) {
  return (
    <div className="flex items-center justify-center py-2">
      <span className="rounded-full bg-ink-100 px-3 py-1 text-xs text-ink-400 dark:bg-ink-800">
        {label}
      </span>
    </div>
  );
}

export default function ChatWindow({ contact, messages, currentUserId, onSendMessage }) {
  const [draft, setDraft] = useState("");
  const [isContactTyping, setIsContactTyping] = useState(false);
  const [showSummary, setShowSummary] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages.length]);

  // Demo only: simulate the other person typing briefly after you send a message.
  const handleSend = (text) => {
    onSendMessage(text);
    setIsContactTyping(true);
    setTimeout(() => setIsContactTyping(false), 2200);
  };

  return (
    <section className="flex h-full flex-1 flex-col bg-paper-50 dark:bg-ink-900">
      <ChatWindowHeader
        contact={contact}
        onSummarize={() => setShowSummary(true)}
        onSearch={() => {}}
      />

      <div ref={scrollRef} className="scrollbar-thin flex-1 space-y-3 overflow-y-auto px-5 py-4">
        <DateDivider label="Today" />
        {messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} isMine={msg.sender === currentUserId} />
        ))}
        {isContactTyping && <TypingIndicator name={contact.displayName} />}
      </div>

      <SmartReplySuggestions
        suggestions={smartReplySuggestions}
        onSelect={(text) => setDraft(text)}
      />

      <MessageInput
        value={draft}
        onChange={setDraft}
        onSend={handleSend}
        onTyping={() => {}}
      />

      {showSummary && (
        <ChatSummaryModal summary={chatSummaryExample} onClose={() => setShowSummary(false)} />
      )}
    </section>
  );
}
