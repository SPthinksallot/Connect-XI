import { useState } from "react";
import { Paperclip, Mic, Send, Smile } from "lucide-react";

export default function MessageInput({ value, onChange, onSend, onTyping }) {
  const [isRecording, setIsRecording] = useState(false);

  const handleChange = (e) => {
    onChange(e.target.value);
    onTyping?.();
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!value.trim()) return;
    onSend(value.trim());
    onChange("");
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="flex items-end gap-2 border-t border-ink-200/10 px-4 py-3"
    >
      <button
        type="button"
        aria-label="Attach media"
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-ink-400 transition-colors hover:bg-ink-100 hover:text-ink-600 dark:hover:bg-ink-800 dark:hover:text-paper-100"
      >
        <Paperclip className="h-5 w-5" />
      </button>

      <div className="flex flex-1 items-center gap-2 rounded-2xl bg-ink-100/70 px-4 py-2.5 dark:bg-ink-800/70">
        <input
          value={value}
          onChange={handleChange}
          placeholder="Type a message…"
          className="flex-1 bg-transparent text-sm text-ink-900 placeholder:text-ink-400 outline-none dark:text-paper-50"
        />
        <button
          type="button"
          aria-label="Add emoji"
          className="text-ink-400 transition-colors hover:text-ink-600 dark:hover:text-paper-100"
        >
          <Smile className="h-5 w-5" />
        </button>
      </div>

      {value.trim() ? (
        <button
          type="submit"
          aria-label="Send message"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-violet-500 text-white transition-colors hover:bg-violet-600"
        >
          <Send className="h-4.5 w-4.5" />
        </button>
      ) : (
        <button
          type="button"
          onMouseDown={() => setIsRecording(true)}
          onMouseUp={() => setIsRecording(false)}
          aria-label="Hold to record voice note"
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full transition-colors ${
            isRecording
              ? "bg-coral-500 text-white"
              : "text-ink-400 hover:bg-ink-100 hover:text-ink-600 dark:hover:bg-ink-800 dark:hover:text-paper-100"
          }`}
        >
          <Mic className="h-5 w-5" />
        </button>
      )}
    </form>
  );
}
