import { useMemo, useState } from "react";
import ChatList from "../components/chat/ChatList";
import ChatWindow from "../components/chat/ChatWindow";
import EmptyState from "../components/chat/EmptyState";
import { chats as initialChats, contacts, currentUser, activeThreadMessages } from "../data/mockData";

export default function ChatPage() {
  const [activeChatId, setActiveChatId] = useState(initialChats[0].id);
  const [chats, setChats] = useState(initialChats);
  const [messagesByChat, setMessagesByChat] = useState({ c1: activeThreadMessages });

  const contactsById = useMemo(
    () => Object.fromEntries(contacts.map((c) => [c.id, c])),
    []
  );

  const activeChat = chats.find((c) => c.id === activeChatId);
  const activeContact = activeChat ? contactsById[activeChat.contactId] : null;
  const activeMessages = messagesByChat[activeChatId] ?? [];

  const handleSelectChat = (chatId) => {
    setActiveChatId(chatId);
    setChats((prev) => prev.map((c) => (c.id === chatId ? { ...c, unreadCount: 0 } : c)));
  };

  const handleSendMessage = (text) => {
    const newMessage = {
      id: `m-${Date.now()}`,
      chatId: activeChatId,
      sender: currentUser.id,
      contentType: "text",
      text,
      status: "sent",
      createdAt: new Date().toISOString(),
    };
    setMessagesByChat((prev) => ({
      ...prev,
      [activeChatId]: [...(prev[activeChatId] ?? []), newMessage],
    }));
    setChats((prev) =>
      prev.map((c) =>
        c.id === activeChatId
          ? { ...c, lastMessage: { text, sender: currentUser.id, createdAt: newMessage.createdAt } }
          : c
      )
    );
  };

  return (
    <div className="flex h-screen w-full overflow-hidden">
      <ChatList
        chats={chats}
        contactsById={contactsById}
        activeChatId={activeChatId}
        onSelectChat={handleSelectChat}
        currentUser={currentUser}
      />
      {activeContact ? (
        <ChatWindow
          contact={activeContact}
          messages={activeMessages}
          currentUserId={currentUser.id}
          onSendMessage={handleSendMessage}
        />
      ) : (
        <EmptyState />
      )}
    </div>
  );
}
